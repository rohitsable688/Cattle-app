
# Cattle App (GitHub-ready)
This repository is a ready-to-upload Flutter project for an **online Marathi cattle buying & selling app** using Firebase (Firestore + Storage).

## What is included
- Flutter app (simplified) in `lib/main.dart`
- `google-services.json` (Android) — already included
- GitHub Actions workflow for building a **debug APK** automatically: `.github/workflows/flutter-build.yml`

## How to use (Quick steps)
1. Create a new GitHub repository (name it `cattle-app` or anything you like).
2. Extract this ZIP and push all files to your repository (main branch).
   ```bash
   git init
   git add .
   git commit -m "Initial commit - cattle app"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo>.git
   git push -u origin main
   ```
3. Go to GitHub → Repository → Actions. The workflow will start automatically. If not, open the latest workflow and click `Run workflow`.
4. After the workflow finishes, go to the workflow run → **Artifacts** → download `app-debug.apk`.
5. Install the APK on your Android device (allow unknown sources).

## Notes
- This project uses the `google-services.json` you provided. If you want to change Firebase project, replace `android/app/google-services.json` with a new one.
- The app uses manual "ठिकाण" entry (village/district). You can later add map/location features.
- The workflow builds a debug APK (unsigned). For Play Store release, follow Flutter docs to sign a release build.

If you want, I can also guide you step-by-step to push to GitHub and download the APK.
