
This folder contains a minimal placeholder for android/app with google-services.json.
When building locally, ensure the Android package name in android/app/build.gradle matches 'com.cattle.app'.
The GitHub Actions environment will perform the Flutter build without modifications for most projects.
