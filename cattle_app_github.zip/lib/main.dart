
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

// Note: google-services.json (Android) must be present at android/app/google-services.json
// Firebase initialization will use default options from that file on Android.

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'गाय-म्हैस बाजार',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.green),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _idx = 0;
  final pages = [AddListingPage(), SearchPage(), DashboardPage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('गाय-म्हैस बाजार')),
      body: pages[_idx],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _idx,
        onTap: (i) => setState(() => _idx = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.add), label: 'नवीन जोडा'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'शोधा'),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'माझी लिस्ट'),
        ],
      ),
    );
  }
}

class AddListingPage extends StatefulWidget {
  const AddListingPage({super.key});
  @override
  State<AddListingPage> createState() => _AddListingPageState();
}

class _AddListingPageState extends State<AddListingPage> {
  final _formKey = GlobalKey<FormState>();
  String _type = 'गाय';
  final _price = TextEditingController();
  final _desc = TextEditingController();
  final _contactName = TextEditingController();
  final _contactNumber = TextEditingController();
  final _location = TextEditingController();
  XFile? _picked;
  final ImagePicker _picker = ImagePicker();
  bool _saving = false;

  Future<void> _pickImage() async {
    final XFile? file = await _picker.pickImage(source: ImageSource.gallery, maxWidth: 800);
    if (file != null) setState(() => _picked = file);
  }

  Future<String?> _uploadImage(XFile file, String id) async {
    try {
      final ref = FirebaseStorage.instance.ref().child('images/$id.jpg');
      await ref.putFile(File(file.path));
      return await ref.getDownloadURL();
    } catch (e) {
      return null;
    }
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() => _saving = true);
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    String? imageUrl;
    if (_picked != null) {
      imageUrl = await _uploadImage(_picked!, id);
    }
    final doc = FirebaseFirestore.instance.collection('listings').doc(id);
    await doc.set({
      'id': id,
      'type': _type,
      'price': _price.text.trim(),
      'description': _desc.text.trim(),
      'contactName': _contactName.text.trim(),
      'contactNumber': _contactNumber.text.trim(),
      'location': _location.text.trim(),
      'imageUrl': imageUrl,
      'createdAt': FieldValue.serverTimestamp(),
    });
    setState(() {
      _saving = false;
      _picked = null;
      _type = 'गाय';
      _price.clear();
      _desc.clear();
      _contactName.clear();
      _contactNumber.clear();
      _location.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('लिस्टिंग अपलोड झाली')));
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Form(
        key: _formKey,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('प्रजाती', style: TextStyle(fontSize: 16)),
          DropdownButton<String>(value: _type, items: const [
            DropdownMenuItem(value: 'गाय', child: Text('गाय')),
            DropdownMenuItem(value: 'म्हैस', child: Text('म्हैस')),
          ], onChanged: (v) => setState(() => _type = v ?? 'गाय')),
          const SizedBox(height: 8),
          TextFormField(controller: _price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'किंमत (₹)'), validator: (v) => (v==null||v.trim().isEmpty)?'किंमत भरा':null),
          const SizedBox(height: 8),
          TextFormField(controller: _desc, decoration: const InputDecoration(labelText: 'वर्णन'), maxLines: 3),
          const SizedBox(height: 8),
          TextFormField(controller: _contactName, decoration: const InputDecoration(labelText: 'संपर्काचे नाव'), validator: (v)=>(v==null||v.trim().isEmpty)?'संपर्क नाव आवश्यक':null),
          const SizedBox(height: 8),
          TextFormField(controller: _contactNumber, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'मोबाईल नंबर'), validator: (v)=>(v==null||v.trim().isEmpty)?'मोबाईल नंबर आवश्यक':null),
          const SizedBox(height: 8),
          TextFormField(controller: _location, decoration: const InputDecoration(labelText: 'ठिकाण (जिल्हा / गाव)'), validator: (v)=>(v==null||v.trim().isEmpty)?'ठिकाण भरा':null),
          const SizedBox(height: 12),
          Row(children: [
            ElevatedButton.icon(onPressed: _pickImage, icon: const Icon(Icons.photo), label: const Text('फोटो निवडा')),
            const SizedBox(width: 12),
            if (_picked != null) const Expanded(child: Text('फोटो निवडलेली')),
          ]),
          const SizedBox(height: 16),
          Center(child: _saving ? const CircularProgressIndicator() : ElevatedButton(onPressed: _submit, child: const Text('सबमिट करा'))),
        ]),
      ),
    );
  }
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  String _query = '';
  String _typeFilter = 'सर्व';

  Stream<QuerySnapshot<Map<String, dynamic>>> get stream {
    return FirebaseFirestore.instance.collection('listings').orderBy('createdAt', descending: true).snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(children: [
          Expanded(child: TextField(decoration: const InputDecoration(hintText: 'ठिकाण किंवा इतर शोधा...'), onChanged: (v)=>setState(()=>_query=v))),
          const SizedBox(width: 8),
          DropdownButton<String>(value: _typeFilter, items: const [
            DropdownMenuItem(value: 'सर्व', child: Text('सर्व')),
            DropdownMenuItem(value: 'गाय', child: Text('गाय')),
            DropdownMenuItem(value: 'म्हैस', child: Text('म्हैस')),
          ], onChanged: (v)=>setState(()=>_typeFilter=v ?? 'सर्व'))
        ]),
      ),
      Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text('काही चूक झाली'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs.where((d) {
            final data = d.data();
            final matchesType = _typeFilter == 'सर्व' || data['type'] == _typeFilter;
            final q = _query.trim().toLowerCase();
            final matchesQuery = q.isEmpty || (data['location'] ?? '').toString().toLowerCase().contains(q) || (data['description'] ?? '').toString().toLowerCase().contains(q);
            return matchesType && matchesQuery;
          }).toList();
          if (docs.isEmpty) return const Center(child: Text('कोणतीही लिस्टिंग नाही'));
          return ListView.builder(itemCount: docs.length, itemBuilder: (context, i) {
            final data = docs[i].data();
            return Card(child: ListTile(
              leading: data['imageUrl'] != null ? Image.network(data['imageUrl'], width:60, height:60, fit:BoxFit.cover) : const Icon(Icons.pets, size:40),
              title: Text('${data['type']} — ₹${data['price']}'),
              subtitle: Text('${data['location']}\n${data['contactName']}'),
              isThreeLine: true,
              onTap: ()=>showDialog(context: context, builder: (_)=>AlertDialog(
                title: Text('${data['type']} — ₹${data['price']}'),
                content: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  if (data['imageUrl'] != null) Image.network(data['imageUrl']),
                  const SizedBox(height:6),
                  Text('वर्णन: ${data['description']}'),
                  const SizedBox(height:6),
                  Text('ठिकाण: ${data['location']}'),
                  const SizedBox(height:6),
                  Text('संपर्क: ${data['contactName']} — ${data['contactNumber']}'),
                ])),
                actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('बंद')), TextButton(onPressed: () async {
                  final uri = Uri.parse('tel:${data['contactNumber']}');
                  if (await canLaunchUrl(uri)) await launchUrl(uri);
                }, child: const Text('Call'))],
              )),
            ));
          });
        },
      ))
    ]);
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('माहिती', style: TextStyle(fontSize:20, fontWeight: FontWeight.bold)),
      const SizedBox(height:12),
      StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream: FirebaseFirestore.instance.collection('listings').snapshots(), builder: (context, snapshot) {
        final total = snapshot.hasData ? snapshot.data!.docs.length : 0;
        final cows = snapshot.hasData ? snapshot.data!.docs.where((d) => d.data()['type']=='गाय').length : 0;
        final buffalo = snapshot.hasData ? snapshot.data!.docs.where((d) => d.data()['type']=='म्हैस').length : 0;
        return Column(children: [
          Card(child: ListTile(title: const Text('एकूण लिस्टिंग'), trailing: Text('$total'))),
          Card(child: ListTile(title: const Text('गाय'), trailing: Text('$cows'))),
          Card(child: ListTile(title: const Text('म्हैस'), trailing: Text('$buffalo'))),
        ]);
      })
    ]));
  }
}
